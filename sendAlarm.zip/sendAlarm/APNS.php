<?php
 $deviceToken = $_GET["deviceToken"];
 $message = $_GET["message"];
 $sound = $_GET["sound"];
 $badge = $_GET["badge"];

function sendAlarmPush($deviceToken,$message,$sound,$badge){
// Production mode
//$certificateFile = 'output.pem';
//$pushServer = 'ssl://gateway.push.apple.com:2195';
//$feedbackServer = 'ssl://feedback.push.apple.com:2196';
 
// Sandbox mode
$certificateFile = 'eEyes.pem';
// $certificateFile = 'output.pem';
$pushServer = 'ssl://gateway.sandbox.push.apple.com:2195';
$feedbackServer = 'ssl://feedback.sandbox.push.apple.com:2196';
 
// push notification
$streamContext = stream_context_create();           
stream_context_set_option($streamContext, 'ssl', 'local_cert', $certificateFile);
$fp = stream_socket_client(
    $pushServer, 
    $error, 
    $errorStr, 
    100, 
    STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, 
    $streamContext
);
 
// make payload
$payloadObject = array(
    'aps' => array(
        //'alert' => 'Server Time:'.date('Y-m-d H:i:s'),
        //'alert' => 'Your sensor detected something',
        //'alert' => 'sensor 偵測到異常',
        'alert' => $message,
        'sound' => $sound,
        'badge' => $badge
    ),
    'custom_key' => 'custom_value'
);
$payload = json_encode($payloadObject);
 
//11b61c845809af63637804e883f43f219368968149a770d6ab40b25c9d195a3f
//$deviceToken = '38880e1fe3cb9cc2b5f7f2af17ec2676ba79b69fc0d53efa69d34379de2991d6';


//$deviceToken = '11b61c845809af63637804e883f43f219368968149a770d6ab40b25c9d195a3f';
$expire = time() + 3600;
$id = time();
 
if ($expire) {
    // Enhanced mode
    $binary  = pack('CNNnH*n', 1, $id, $expire, 32, $deviceToken, strlen($payload)).$payload;
} else {
    // Simple mode
    $binary  = pack('CnH*n', 0, 32, $deviceToken, strlen($payload)).$payload;
}
if (!$fp) {
        echo "Failed to connect $err $errstr.";
        return;
    }else {
//      echo "Connection OK";
    }
$result = fwrite($fp, $binary);
fclose($fp);
}
 
 sendAlarmPush($deviceToken,$message,$sound,$badge);
?>