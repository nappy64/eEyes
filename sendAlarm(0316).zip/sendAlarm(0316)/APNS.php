<?php
 $deviceToken = $_GET["deviceToken"];
 $message = $_GET["message"];
 $sound = $_GET["sound"];
 $bdg = $_GET["badge"];



function raw_json_encode($input) {

    return preg_replace_callback(
        '/\\\\u([0-9a-zA-Z]{4})/',
        function ($matches) {
            return mb_convert_encoding(pack('H*',$matches[1]),'UTF-8','UTF-16');
        },
        json_encode($input)
    );

}    

function sendAlarmPush($deviceToken,$message,$sound,$badge){
// Production mode
//$certificateFile = 'output.pem';
//$pushServer = 'ssl://gateway.push.apple.com:2195';
//$feedbackServer = 'ssl://feedback.push.apple.com:2196';

 
$badgeNum = (int)$badge;
echo $badgeNum . "<br>";


// Sandbox mode
$certificateFile = 'eEyes.pem';
// $certificateFile = 'output.pem';
$pushServer = 'ssl://gateway.sandbox.push.apple.com:2195';
$feedbackServer = 'ssl://feedback.sandbox.push.apple.com:2196';
 
// push notification
$streamContext = stream_context_create();           
stream_context_set_option($streamContext, 'ssl', 'local_cert', $certificateFile);
$fp = stream_socket_client(
    $pushServer, 
    $error, 
    $errorStr, 
    100, 
    STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, 
    $streamContext
);
 
// make payload
$body = array();
    
    $alert = array('title' => 'Message From eEyes','body' => $message);
    
    $body['aps'] = array('alert' => $alert);
    if ($badge)
        $body['aps']['badge'] = $badgeNum;
    if ($sound)
        $body['aps']['sound'] = $sound;

$payloadObject = $body;
$payload = raw_json_encode($body);//json_encode($body);
//$payload = json_encode($payloadObject);
 
//11b61c845809af63637804e883f43f219368968149a770d6ab40b25c9d195a3f
//$deviceToken = '38880e1fe3cb9cc2b5f7f2af17ec2676ba79b69fc0d53efa69d34379de2991d6';


//$deviceToken = '11b61c845809af63637804e883f43f219368968149a770d6ab40b25c9d195a3f';
$expire = time() + 3600;
$id = time();

print_r($body);
 
if ($expire) {
    // Enhanced mode
    $binary  = pack('CNNnH*n', 1, $id, $expire, 32, $deviceToken, strlen($payload)).$payload;
} else {
    // Simple mode
    $binary  = pack('CnH*n', 0, 32, $deviceToken, strlen($payload)).$payload;
}
if (!$fp) {
        echo "Failed to connect $err $errstr.";
        return;
    }else {
//      echo "Connection OK";
    }
$result = fwrite($fp, $binary);
fclose($fp);
}





sendAlarmPush($deviceToken,$message,$sound,$bdg);
?>