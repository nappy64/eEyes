<?php
error_reporting(0);
include "./APNS.php";
include "./sendEmail.php";
include "./sendSMS.php";


// $dbhost = "localhost";              // 資料庫位置
// $dbuser = $_GET[username];          // 帳戶名稱
// $dbpass = $_GET[password];          // 帳戶密碼
// $dbname = $_GET[database];          // 資料庫名稱
// $dbtable = $_GET[table];            // 資料表
// $dbfield = $_GET[field];            // 資料欄位
// $dbdatefield = $_GET[datefield];    // 時間欄位
// $dbstartdate = $_GET[startdate];    // 開始時間
// $type = $_GET[type];                // 動作
// $message = $_GET[msg];



// $db = new pdo("mysql:host=$dbhost;port=8889",$dbuser,$dbpass);  // 連結 MySQL
// $db->query("set names 'utf8'");     // 1. 設定連接的編碼
// $db->query("use `$dbname`");        // 2. 使用資料庫

function sendAlarmToAll($subject,$message){
	global $db;
	$sql = "SELECT DeviceToken FROM deviceToken WHERE UserName LIKE 'root'";
	$result = $db->query($sql)->fetchall();
	// print_r($result);
	$eachDT = "";

	foreach ($result as $key => $value) {
		// print_r($value);
		//echo $value[DeviceToken];
		$eachDT = $value[DeviceToken];
		echo $eachDT."<br>";	
		sendAlarmPush($eachDT,$message,"default","1");
	}

	//SELECT `Email`, `AlarmBySMS` FROM `UserInfo` WHERE `Username` LIKE "Denny"
		// query user email and send it if it's AlarmByEmail is 1

	$sql = "SELECT `Email`, `AlarmBySMS` FROM `UserInfo` WHERE `AlarmByEmail` != 0";
	$emailInfo = $db->query($sql)->fetchall();
	$eachEmail = "";
	foreach ($emailInfo as $key => $value) {
		$eachEmail = $value[Email];
		echo $eachEmail."<br>";
		sendEmail($dbuser,$eachEmail,$subject,$message);
	}

	// query user phone number
	$sql = "SELECT `PhoneNumber` FROM `UserInfo` WHERE `AlarmBySMS` != 0";
	$smsInfo = $db->query($sql)->fetchall();
	$eachPhone = "";

	foreach ($smsInfo as $key => $value) {
		$eachPhone = $value[PhoneNumber];
		echo $eachPhone."<br>";
		sendSMS($message,$eachPhone);
	}
}



// Test URL: http://127.0.0.1/dbAlarm_GET.php?username=root&password=root&database=eEyes&msg=AllAlarmTest%E4%B8%AD%E6%96%87%E6%B8%AC%E8%A9%A6%E5%8A%A0%E4%B8%8A%E7%B0%A1%E8%A8%8A5




?>