<?php
 
// Production mode
//$certificateFile = 'output.pem';
//$pushServer = 'ssl://gateway.push.apple.com:2195';
//$feedbackServer = 'ssl://feedback.push.apple.com:2196';
 
// Sandbox mode
$certificateFile = 'eEyes.pem';
$pushServer = 'ssl://gateway.sandbox.push.apple.com:2195';
$feedbackServer = 'ssl://feedback.sandbox.push.apple.com:2196';
 
// push notification
$streamContext = stream_context_create();           
stream_context_set_option($streamContext, 'ssl', 'local_cert', $certificateFile);
$fp = stream_socket_client(
    $pushServer, 
    $error, 
    $errorStr, 
    100, 
    STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, 
    $streamContext
);
 
// make payload
$payloadObject = array(
    'aps' => array(
        //'alert' => 'Server Time:'.date('Y-m-d H:i:s'),
        //'alert' => 'Your sensor detected something',
        //'alert' => 'sensor 偵測到異常',
        //'alert' => 'Sensor偵測到異常溫度',
        //'sound' => 'default',
        //'badge' => 1
        'content-available' => 1
 
    ),
     //'custom_key' => 'custom_value'
     'acme1' => 'bar',
     'acme2' => 42
);
$payload = json_encode($payloadObject);
 
$deviceToken = '9d00cf849e4cadd4ecd7828ef161ff6c81976637441176c6e4a98d4ed188d0c9';
$expire = time() + 3600;
$id = time();
 
if ($expire) {
    // Enhanced mode
    $binary  = pack('CNNnH*n', 1, $id, $expire, 32, $deviceToken, strlen($payload)).$payload;
} else {
    // Simple mode
    $binary  = pack('CnH*n', 0, 32, $deviceToken, strlen($payload)).$payload;
}
$result = fwrite($fp, $binary);
fclose($fp);
 
?>