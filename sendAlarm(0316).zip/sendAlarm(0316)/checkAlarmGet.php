<?php
//error_reporting(0);
ignore_user_abort();//關掉瀏覽器，PHP腳本也可以繼續執行.
//set_time_limit(0);// 通過set_time_limit(0)可以讓程式無限制的執行下去 
include './dbAlarm_GET.php';
// http://localhost/checkAlarmGet.php?username=root&password=root&database=eEyes&sensorID=2&appUserName=user&type=checkAlarm
// http://127.0.0.1/checkAlarmGet.php?username=root&password=root&database=eEyes&appUserName=user&type=checkAlarm&sec=10

$dbhost = "localhost";              // 資料庫位置
$dbuser = $_GET[username];          // 帳戶名稱
$dbpass = $_GET[password];          // 帳戶密碼
$dbname = $_GET[database];          // 資料庫名稱
$appName = $_GET[appUserName];      // app user name
$dbtable = $_GET[table];            // 資料表
$type = $_GET[type];                // 動作
$sec = $_GET[sec];


$db = new pdo("mysql:host=$dbhost;port=8889",$dbuser,$dbpass);  // 連結 MySQL
$db->query("set names 'utf8'");     // 1. 設定連接的編碼
$db->query("use `$dbname`");        // 2. 使用資料庫



$index = 0;
$interval = $sec;// 每次執行的時間間隔
do{
    checkAlarms($appName,$type);
    sleep($interval);// 等待
    date_default_timezone_set('Asia/Taipei');
    //取得年份/月/日 時:分:秒
    $datetime = date("Y-m-d H:i:s");
    echo $datetime."<br>";
    if ($index == 0) {
        break;
    }
    $index ++;
}while(true);  

function checkAlarms($appName,$type){
    // get UserID by user name
    global $db;
    $userID = "";

    foreach ($db->query("SELECT * FROM `UserInfo` WHERE (`Username` = '$appName')") as $key => $value) {        
        $userID = $value["UserID"];
    }

    // if username not existed
    if($userID == "") {
        echo '{"result":false,"errorCode":"USER_NAME_NOT_EXIST"}';
    } else {
        // get sensor count
        $pageCount = ceil($db->query("SELECT COUNT(`SensorID`) FROM `SensorInfo` WHERE `UserID`='1'")->fetchColumn(0));

        if($pageCount == 0) {
            echo '{"result":false,"errorCode":"NO_SENSOR_WITH_USER"}';
        } else {
            // get sensor 1 hi/lo alarm
            foreach ($db->query("SELECT * FROM `SensorInfo` WHERE (`SensorID` = '1')") as $key => $value) {
                $hiAlarm1 = $value["HiAlarmValue"];
                $loAlarm1 = $value["LoAlarmValue"];
            }

            // get sensor 2 hi/lo alarm
            foreach ($db->query("SELECT * FROM `SensorInfo` WHERE (`SensorID` = '2')") as $key => $value) {
                $hiAlarm2 = $value["HiAlarmValue"];
                $loAlarm2 = $value["LoAlarmValue"];
            }

            $hiAlarmStr = "Hi Alarm";
            $loAlarmStr = "Low Alarm";

            // echo "sensor 2 : " . $hiAlarm2 . " " . $loAlarm2 . "<br>";

            // while(1) {
                // date_default_timezone_set('Asia/Taipei');//設定時區為台北
                //$now = date('Y-m-d H:i:s');

                $now = "2017-03-10 00:21:49";
                // while(1) {
                    sleep(1);
                    // get sensor 1 newest value
                    foreach ($db->query("SELECT * FROM `RealID10001` WHERE (`Date` > '$now')") as $key => $value) {
                        $rValue = $value["RealValue"];
                        $rDate = $value["Date"];

                        // check if hi/lo alarm
                        if($rValue > $hiAlarm1) {
                            // echo '{"id":1,"value":'.$rValue.',"alarmValue":'.$hiAlarm1.',"date":'.$rDate.',"errorCode":"HI_ALARM"}';
                            $db->query("INSERT INTO `AlarmRecord` (`SensorID`, `DateTime`, `AlarmValue`, `AlarmType`) VALUES ('1', '$rDate', '$rValue', '$hiAlarmStr')");
                            $subject = "溫度過高警報";
                            $message = '偵測到溫度高於'. $hiAlarm1 .'度，且高至'. $rValue .'度';
                            sendAlarmToAll($subject,$message);
                        } else if($rValue < $loAlarm1) {
                            // echo '{"id":1,"value":'.$rValue.',"alarmValue":'.$loAlarm1.',"date":'.$rDate.',"errorCode":"LO_ALARM"}';
                            $db->query("INSERT INTO `AlarmRecord` (`SensorID`, `DateTime`, `AlarmValue`, `AlarmType`) VALUES ('1', '$rDate', '$rValue', '$loAlarmStr')");
                            $subject = "溫度過低警報";
                            $message = '偵測到溫度低於'. $loAlarm1.'度，且低至'.$rValue .'度';
                            sendAlarmToAll($subject,$message);
                        }
                    }

                    // echo "<br>";

                    // get sensor 2 newest value
                    foreach ($db->query("SELECT * FROM `RealID10002` WHERE (`Date` > '$now')") as $key => $value) {
                        $rValue = $value["RealValue"];
                        $rDate = $value["Date"];

                        // check if hi/lo alarm
                        if($rValue > $hiAlarm2) {
                            // echo '{"id":2,"value":'.$rValue.',"alarmValue":'.$hiAlarm2.',"date":'.$rDate.',"errorCode":"HI_ALARM"}';
                            $db->query("INSERT INTO `AlarmRecord` (`SensorID`, `DateTime`, `AlarmValue`, `AlarmType`) VALUES ('2', '$rDate', '$rValue', '$hiAlarmStr')");
                            
                            // Send Alarm
                            $subject = "濕度過高警報";
                            $message = '偵測到濕度高於'. $hiAlarm2 .'%，且高至'.$rValue.'%';
                            sendAlarmToAll($subject,$message);

                        } else if($rValue < $loAlarm2) {
                            // echo '{"id":2,"value":'.$rValue.',"alarmValue":'.$loAlarm2.',"date":'.$rDate.',"errorCode":"LO_ALARM"}';
                            $db->query("INSERT INTO `AlarmRecord` (`SensorID`, `DateTime`, `AlarmValue`, `AlarmType`) VALUES ('2', '$rDate', '$rValue', '$loAlarmStr')");

                            $subject = "濕度過低警報";
                            $message = '偵測到濕度低於'. $loAlarm2 .'%，且低至'.$rValue.'%';
                            sendAlarmToAll($subject,$message);
                        }
                    }
            // }
        }
    }
}

?>